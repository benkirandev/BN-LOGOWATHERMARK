# Logo-Watermark
## What Is Logo Watermark? 
Logo Watermark is a ridiculously easy script that I was requested to make and couldn't fathom charging for so here it is for free. All this does is simply draw a logo over your screen (similar to a watermark). I also added a simple fade-in/fade-out animation when opening and closing your map. If there is actual interest in this I will update it and add a toggle watermark command that will have the option to be permission-based. Otherwise, enjoy!

## How To Change Logo
* Simply navigate to the `img` folder and change the logo to your own
* YOU MUST NAME THE IMAGE `logo.png` OR IT WILL NOT WORK
* Please for the love of god read the above line

## How Can I Change The Position, Size, ETC..
* Edit the `style.css` located in the `html` folder
* I will not provide support for any edits made to the files.

## Showcase:
[Click Me!](https://i.imgur.com/CtIN49K.gif)