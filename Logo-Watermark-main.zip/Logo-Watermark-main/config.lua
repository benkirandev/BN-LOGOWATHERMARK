config = {
    allowoff = true -- Should the player be able to turn off the watermark?
}